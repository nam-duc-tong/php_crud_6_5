<?php
    include "db/connection.php";
    $id = $_GET['id'];
    $sql = "DELETE FROM `crud` WHERE id = $id";
    $result = mysqli_query($conn,$sql);
    if($result){
        header("Location: index.php?msg=Record deleted SuccessFully");
    }
    else{
        echo "Error".mysqli_error($conn);
    }
?>